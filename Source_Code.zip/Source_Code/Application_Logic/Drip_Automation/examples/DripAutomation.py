#!/usr/bin/python

import json
import sys
import time
import datetime
import RPi.GPIO as GPIO
import spidev
from time import sleep

import Adafruit_DHT
import gspread
from oauth2client.service_account import ServiceAccountCredentials

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(15,GPIO.OUT)
GPIO.setup(18,GPIO.OUT)
GPIO.setup(23,GPIO.OUT)

GPIO.output(18,GPIO.HIGH)
GPIO.output(15,GPIO.LOW)
GPIO.output(23,GPIO.LOW)

# Type of sensor, can be Adafruit_DHT.DHT11, Adafruit_DHT.DHT22, or Adafruit_DHT.AM2302.
DHT_TYPE = Adafruit_DHT.AM2302

# Example of sensor connected to Raspberry Pi pin 23
DHT_PIN  = 4

GDOCS_OAUTH_JSON = 'Drip_Automation-d9effef25759.json'

# Google Docs spreadsheet name.
GDOCS_SPREADSHEET_NAME = 'Sensor_Readings'

# Google Docs spreadsheet2 name.
GDOCS_THRESHOLDSHEET_NAME = 'Threshold_Values_from_WebApp'

# How long to wait (in seconds) between measurements.
FREQUENCY_SECONDS      = 15

# Establish SPI device on Bus 0,Device 0
spi = spidev.SpiDev()
spi.open(0,0)

msum = 0
tsum = 0
hsum = 0

def login_open_sheet(oauth_key_file, spreadsheet):
    """Connect to Google Docs spreadsheet and return the first worksheet."""
    try:
        scope =  ['https://spreadsheets.google.com/feeds']
        credentials = ServiceAccountCredentials.from_json_keyfile_name(oauth_key_file, scope)
        gc = gspread.authorize(credentials)
        worksheet = gc.open(spreadsheet).sheet1
        return worksheet
    except Exception as ex:
        print('Unable to login and get spreadsheet.  Check OAuth credentials, spreadsheet name, and make sure spreadsheet is shared to the client_email address in the OAuth .json file!')
        print('Google sheet login failed with error:', ex)
        sys.exit(1)
		
def findMoistureSum(num,i):
	global msum
	if i == 1:
		msum = 0
	msum += num
	return msum
	
def findTempSum(num,i):
	global tsum
	if i == 1:
		tsum = 0
	tsum = tsum + num
	return tsum
	
def findHumiditySum(num,i):
	global hsum
	if i == 1:
		hsum = 0
	hsum = hsum + num
	return hsum

def dripAuto (channel,temp,humidity,FREQUENCY_SECONDS,sheet,worksheet,i):
		#check valid channel
		if ((channel>7)or(channel<0)):
				return -1

		# Preform SPI transaction and store returned bits in 'r'
		r = spi.xfer([1, (8+channel) << 4, 0])
		
		print('{0}'.format(i))
		#Filter data bits from retruned bits
		adcOut = ((r[1]&3) << 8) + r[2]
		value = 1023 - adcOut
		moisture = value/float(10.23)
		lastRow = sheet.row_count;
		moistureThreshold = sheet.cell(lastRow,1).value
		tempThreshold = sheet.cell(lastRow,2).value
		humidityThreshold = sheet.cell(lastRow,3).value
		moistureSum = findMoistureSum(moisture,i)
		tempSum = findTempSum(temp,i)
		humiditySum = findHumiditySum(humidity,i)
		if i == 4:
			print('Threshold Values are:')
			print('Moisture Threshold: {0}'.format(moistureThreshold))
			print('Temperature Threshold: {0}'.format(tempThreshold))
			print('Humidity Threshold: {0}'.format(humidityThreshold))
			meanMoisture = int(moistureSum/4)
			meanTemp = int(tempSum/4)
			meanHumidity = int(humiditySum/4)
			
			if int(meanMoisture) < int(moistureThreshold):
				if int(meanTemp) > int(tempThreshold):
					print('motor on')
					GPIO.output(18,GPIO.LOW)
					GPIO.output(23,GPIO.LOW)
					GPIO.output(15,GPIO.HIGH)
				else:
					if int(meanHumidity) < int(humidityThreshold):
						print('motor on')
						GPIO.output(18,GPIO.LOW)
						GPIO.output(23,GPIO.LOW)
						GPIO.output(15,GPIO.HIGH)
					else:
						print('motor off')
						GPIO.output(18,GPIO.LOW)
						GPIO.output(23,GPIO.HIGH)
						GPIO.output(15,GPIO.LOW)
			else:
				print('motor off')
				GPIO.output(18,GPIO.LOW)
				GPIO.output(23,GPIO.HIGH)
				GPIO.output(15,GPIO.LOW)
			
		#print out 0-1023 value and percentage
		print('Temperature: {0:0.1f} C'.format(temp))
		print('Humidity:    {0:0.1f} %'.format(humidity))
		print('Moisture: {0:3} %'.format(moisture))
		
		# Append the data in the spreadsheet, including a timestamp
		try:
			worksheet.append_row((datetime.datetime.now(), temp, humidity, moisture))
		except:
			# Error appending data, most likely because credentials are stale.
			# Null out the worksheet so a login is performed at the top of the loop.
			print('Append error, logging in again')
			worksheet = None
			time.sleep(FREQUENCY_SECONDS)
			
		
print('Logging sensor measurements to {0} every {1} seconds.'.format(GDOCS_SPREADSHEET_NAME, FREQUENCY_SECONDS))
print('Press Ctrl-C to quit.')
worksheet = None
i = 1
while True:
    # Login if necessary.
    if worksheet is None:
        worksheet = login_open_sheet(GDOCS_OAUTH_JSON, GDOCS_SPREADSHEET_NAME)
	
	sheet = login_open_sheet(GDOCS_OAUTH_JSON, GDOCS_THRESHOLDSHEET_NAME)

    # Attempt to get sensor reading.
    humidity, temp = Adafruit_DHT.read(DHT_TYPE, DHT_PIN)

    # Skip to the next reading if a valid measurement couldn't be taken.
    # This might happen if the CPU is under a lot of load and the sensor
    # can't be reliably read (timing is critical to read the sensor).
    if humidity is None or temp is None:
        time.sleep(2)
        continue
    
    if i == 5:
		i=1
	
    dripAuto(2,temp,humidity,FREQUENCY_SECONDS,sheet,worksheet,i)
    i = i+1
    continue

    # Wait 30 seconds before continuing
    print('Wrote a row to {0}'.format(GDOCS_SPREADSHEET_NAME))
    time.sleep(FREQUENCY_SECONDS)
